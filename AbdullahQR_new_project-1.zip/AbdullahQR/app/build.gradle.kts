plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.abdullah.qr"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.abdullah.qr"
        minSdk = 24
        targetSdk = 34
        versionCode = 6
        versionName = "6.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Built-in QR/barcode scanner UI (uses Google Play services on the phone)
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
}
